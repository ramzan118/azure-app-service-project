# azure-app-service-project
azure-app-service-project with Ajax, .Net and sql
